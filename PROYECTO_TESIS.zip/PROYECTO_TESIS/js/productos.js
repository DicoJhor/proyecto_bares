// Lista de productos de ejemplo
const productos = [
    { id: 1, nombre: "Hamburguesa", precio: 15.50 },
    { id: 2, nombre: "Pizza", precio: 20.00 },
    { id: 3, nombre: "Ensalada César", precio: 12.00 },
    { id: 4, nombre: "Sopa de Pollo", precio: 10.00 },
    { id: 5, nombre: "Tacos", precio: 18.00 },
    { id: 6, nombre: "Papas Fritas", precio: 8.00 },
    { id: 7, nombre: "Cóctel de Frutas", precio: 9.00 },
    { id: 8, nombre: "Refresco", precio: 5.00 },
    { id: 9, nombre: "Cerveza", precio: 10.00 }
  ];
  